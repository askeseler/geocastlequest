import os
# Store the hashed password here
SALT = "$2b$12$e9MZqweZqL49XhK9RtDfve"

# Define constants
SAFE_PORTS = [80, 8080, 8002]
ALLOWED_ROOT = "~/projects"