pyuic5 -o UserInterface.py UserInterface.ui
