import os
import bcrypt
import subprocess
import argparse
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from getpass import getpass
from server_settings import SALT

# Constants
SAFE_PORTS = [8000, 8001, 8002]
ALLOWED_DIR = os.path.expanduser("~/projects")

# FastAPI application
app = FastAPI()
PWD = None

# --- Utility Functions ---

def sanitize_path(path: str) -> str:
    """
    Sanitizes the given path by:
    1. Ensuring the file ends with .zip
    2. Ensuring the directory matches the allowed root directory
    3. Ensuring the directory does not contain 'backend' or 'build'
    4. Ensuring the path does not contain '..' or '.'
    """
    # Step 1: Extract filename and directory
    filename = os.path.basename(path)
    dir_name = os.path.dirname(path)

    if '..' in dir_name or '.' in dir_name:
        raise ValueError(f"Invalid path: {dir_name} contains forbidden patterns '..' or '.'.")

    if not (filename.endswith(".zip") or filename.endswith(".sh")):
        raise ValueError(f"Invalid filename: {filename} does not end with .zip.")

    abs_dir = os.path.abspath(dir_name)
    abs_allowed_dir = os.path.abspath(ALLOWED_DIR)

    if not abs_dir.startswith(abs_allowed_dir):
        raise ValueError(f"Invalid path: {abs_dir} is outside the allowed root directory.")

    if 'backend' in abs_dir or 'build' in abs_dir:
        raise ValueError(f"Invalid path: {abs_dir} contains forbidden directory names 'backend' or 'build'.")

    return os.path.normpath(path)

def sanitize_port(port: int) -> int:
    if port not in SAFE_PORTS:
        raise ValueError(f"Port {port} is not allowed. Use one of {SAFE_PORTS}")
    return port

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), SALT.encode("utf-8")).decode()

def verify_password(provided: str) -> bool:
    global PWD
    return PWD == provided

def run_command(command: str) -> bool:
    try:
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
        if process.returncode == 0:
            return True
        else:
            print(f"Command failed with error: {stderr.decode()}")
            return False
    except Exception as e:
        print(f"Error executing command: {str(e)}")
        return False

# --- Request Models ---

class StartServerRequest(BaseModel):
    script_path: str
    password: str

class StopServerRequest(BaseModel):
    port: int
    password: str

class CleanUpRequest(BaseModel):
    path: str
    password: str

class TransferRequest(BaseModel):
    path: str
    password: str

class UnzipRequest(BaseModel):
    path: str
    password: str

# --- API Endpoints ---

@app.post("/api/deployment/start_server/")
async def start_server(request: StartServerRequest):
    try:
        if not verify_password(request.password):
            raise HTTPException(status_code=403, detail="Invalid password")
        path = sanitize_path(request.script_path)
        if run_command(f"bash {path}"):
            return {"status": "success", "message": f"Server started with script {path}"}
        raise HTTPException(status_code=500, detail="Failed to start server")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/deployment/stop_server/")
async def stop_server(request: StopServerRequest):
    try:
        if not verify_password(request.password):
            raise HTTPException(status_code=403, detail="Invalid password")
        port = sanitize_port(request.port)
        if run_command(f"fuser -k {port}/tcp"):
            return {"status": "success", "message": f"Server stopped at port {port}"}
        raise HTTPException(status_code=500, detail="Failed to stop server")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/deployment/clean_up/")
async def clean_up(request: CleanUpRequest):
    try:
        if not verify_password(request.password):
            raise HTTPException(status_code=403, detail="Invalid password")
        path = sanitize_path(request.path)
        if run_command(f"rm -rf {path}"):
            return {"status": "success", "message": f"Cleaned up path: {path}"}
        raise HTTPException(status_code=500, detail="Failed to clean up")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/deployment/transfer/")
async def transfer(path: str = Form(...), password: str = Form(...), file: UploadFile = File(...)):
    try:
        if not verify_password(password):
            raise HTTPException(status_code=403, detail="Invalid password")
        full_path = sanitize_path(path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        file_path = os.path.join(full_path, file.filename)
        with open(file_path, "wb") as buffer:
            buffer.write(await file.read())
        return {"status": "success", "message": f"File saved to {file_path}"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/deployment/unzip/")
async def unzip(request: UnzipRequest):
    try:
        if not verify_password(request.password):
            raise HTTPException(status_code=403, detail="Invalid password")
        path = sanitize_path(request.path)
        unzip_dir = os.path.dirname(path)
        if run_command(f'cd {unzip_dir} && unzip -o {os.path.basename(path)}'):
            return {"status": "success", "message": f"Unzipped file at {path}"}
        raise HTTPException(status_code=500, detail="Failed to unzip file")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

# --- Server Start Logic ---

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Start the FastAPI server with password protection.")
    parser.add_argument("--port", type=int, default=80, help="Port to start the server on (default: 80)")
    parser.add_argument("--password", type=str, help="Password for server access")
    args = parser.parse_args()

    if args.password is None:
        password = getpass(prompt="Enter the server password: ")
        hashed_pwd = hash_password(password)
        port = args.port
        command = f"python server.py --password '{hashed_pwd}' --port {port}"
        print(f"Launching: {command}")
        subprocess.Popen(command, shell=True)
    else:
        PWD = args.password
        import uvicorn
        uvicorn.run(app, host="0.0.0.0", port=args.port)
