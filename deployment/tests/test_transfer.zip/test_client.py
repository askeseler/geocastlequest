import os
import bcrypt
import requests
from getpass import getpass
from server_settings import SALT

def hash_password(password: str) -> str:
    """
    Returns a deterministic bcrypt hash of the given password using a fixed salt.
    The salt must be 29 characters starting with '$2b$12$'.
    """
    global SALT
    hashed = bcrypt.hashpw(password.encode("utf-8"), SALT.encode("utf-8")).decode()
    print(hashed)
    return hashed

class FrontendTestClient:
    def __init__(self, host="147.182.240.53", port=80):
        self.base_url = f"http://{host}:{port}/api/deployment/"
        self.server_pwd = getpass("Enter password: ")
        self.server_pwd = hash_password(self.server_pwd)
        self.no_proxy = {"http": None, "https": None}

    def hash_password(self, password: str, salt: str) -> str:
        """
        Returns a deterministic bcrypt hash of the given password using a fixed salt.
        The salt must be 29 characters starting with '$2b$12$'.
        """
        if not salt.startswith("$2b$12$") or len(salt) != 29:
            raise ValueError("Salt must be a 29-character bcrypt salt starting with '$2b$12$'")

        password_bytes = password.encode('utf-8')
        salt_bytes = salt.encode('utf-8')
        hashed = bcrypt.hashpw(password_bytes, salt_bytes)
        return hashed.decode('utf-8')

    def _print_response(self, label, response):
        print(f"--- {label} ---")
        print(f"Status Code: {response.status_code}")
        try:
            print("Response:", response.json())
        except Exception:
            print("Raw Response:", response.text)
        print()

    def stop_server(self, port=8002):
        url = self.base_url + "stop_server/"
        data = {
            "password": self.server_pwd,
            "port": port
        }
        response = requests.post(url, json=data, proxies=self.no_proxy)
        self._print_response("Stop Server", response)

    def start_server(self, script_path):
        url = self.base_url + "start_server/"
        data = {
            "password": self.server_pwd,
            "script_path": script_path
        }
        response = requests.post(url, json=data, proxies=self.no_proxy)
        self._print_response("Start Server", response)

    def unzip(self, path):
        url = self.base_url + "unzip/"
        data = {
            "password": self.server_pwd,
            "path": path
        }
        response = requests.post(url, json=data, proxies=self.no_proxy)
        self._print_response("Unzip", response)

    def transfer(self, path, test_file):
        url = self.base_url + "transfer/"
        full_path = os.path.expanduser(path)
        os.makedirs(full_path, exist_ok=True)

        with open(test_file, "rb") as file_data:
            files = {
                "file": ("test_transfer.zip", file_data, "application/zip")
            }
            data = {"password": self.server_pwd, "path": path}
            response = requests.post(url, data=data, files=files, proxies=self.no_proxy)
            self._print_response("Transfer", response)

if __name__ == "__main__":
    client = FrontendTestClient()

    # Test values
    valid_path = "~/projects/testdir"
    script_path = "~/projects/humusmonitor/run.sh"

    test_file = os.path.join("./", "test_transfer.zip")
    with open(test_file, "wb") as f:
        f.write(os.urandom(1024))  # 1KB dummy zip file

    client.stop_server()
    client.start_server(script_path)
    client.transfer(valid_path)
    client.unzip(valid_path)